package com.aless.fysiohellevoetsluis;


public class Constants {

    private static final String ROOT_URL = "http://www.twintronix.nl/tess_kok/Android/v1/";

    public static final String URL_REGISTER = ROOT_URL+"registerUser.php";
    public static final String URL_LOGIN = ROOT_URL+"userLogin.php";
    public static final String URL_Videotrainen = ROOT_URL+ "getVideoTrainen.php";
    public static final String URL_FAVORITE = ROOT_URL+"getUserFavoriteVideo.php";
    public static final String URL_CAT = ROOT_URL+"getOefCat.php";
    public static final String URL_VideoWarmingUp = ROOT_URL+"getVideoWarmingUp.php";
    public static final String URL_addtofav = ROOT_URL+"delete.php";

}
