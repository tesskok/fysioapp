package com.aless.fysiohellevoetsluis;


//this is very simple class and it only contains the user attributes, a constructor and the getters
// you can easily do this by right click -> generate -> constructor and getters
public class User {

    private int Userid;


    public User(int Userid) {
        this.Userid = Userid;


    }

    public int getUserId() {
        return Userid;
    }



}
