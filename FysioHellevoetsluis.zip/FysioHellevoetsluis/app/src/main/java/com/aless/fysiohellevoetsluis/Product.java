package com.aless.fysiohellevoetsluis;


public class Product {
    private int id;
    private String title;
    private String shortdesc;
    private String video;
    private String image;

    public Product(int id, String title, String shortdesc, String video, String image) {
        this.id = id;
        this.title = title;
        this.shortdesc = shortdesc;
        this.video = "http://www.twintronix.nl/tess_kok/uploads/"+video;
        this.image = "http://www.twintronix.nl/tess_kok/uploads/"+image;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getShortdesc() {
        return shortdesc;
    }

    public String getVideo(){return video;}

    public String getImage() {
        return image;
    }

}
