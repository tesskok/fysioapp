package com.aless.fysiohellevoetsluis;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

/**
 * Created by Tess on 25-03-18.
 */

public class GalleryActivity  extends AppCompatActivity{
   private static final String TAG ="GalleryActivity";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gallery);
        Log.d(TAG, "onCreate: started");

        getIncomingIntent();
    }

    private void getIncomingIntent(){
        Log.d(TAG, "getIncomingIntent:checking for");
        if (getIntent().hasExtra("video") && getIntent().hasExtra("title")&& getIntent().hasExtra("uitleg")){
            Log.d(TAG, "getIncomingIntent; found");

            String video = getIntent().getStringExtra("video");
            String title = getIntent().getStringExtra("title");
            String uitleg = getIntent().getStringExtra("uitleg");

            setImage(video, title, uitleg);
        }
    }

    private void setImage(String video, String title, String uitleg) {
        Log.d(TAG, "setImage:fsdfsd");

        TextView Uitleg = findViewById(R.id.image_uitleg);
        Uitleg.setText(uitleg);

        TextView Title = findViewById(R.id.image_title);
        Title.setText(title);

        ImageView Video = findViewById(R.id.ViewVideo);
        Glide.with(this)
                .asBitmap()
                .load(video)
                .into(Video);
    }

}
