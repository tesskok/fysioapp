package com.aless.fysiohellevoetsluis;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;


public class OefcatAdapter extends RecyclerView.Adapter<OefcatAdapter.ProductViewHolder> {


    private Context mCtx;
    private List<Oefcat> oefcatList;

    public OefcatAdapter(Context mCtx, List<Oefcat> oefcatList) {
        this.mCtx = mCtx;
        this.oefcatList = oefcatList;
    }

    @Override
    public ProductViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.oefcat_list, null);
        return new ProductViewHolder(view);

    }

    @Override
    public void onBindViewHolder(ProductViewHolder holder, int position) {
        final Oefcat oefcat = oefcatList.get(position);


        holder.textViewTitle.setText(oefcat.getOefcat());
        holder.relativeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View View){
                Toast.makeText(mCtx,"U heeft gekozen voor het trainen van de  " + oefcat.getOefcat(), Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(mCtx, MainActivityVideo.class);
                intent.putExtra("oefcat", oefcat.getOefcat());
                mCtx.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return oefcatList.size();
    }

    public class ProductViewHolder extends RecyclerView.ViewHolder {

        public TextView textViewTitle;
        public RelativeLayout relativeLayout;

        public ProductViewHolder(View itemView) {
            super(itemView);

            textViewTitle = itemView.findViewById(R.id.buttonoefcat);
            relativeLayout =  itemView.findViewById(R.id.relativeLayoutoefcat);

        }
    }
}
