package com.aless.fysiohellevoetsluis;


public class Oefcat {
    private int oefcatid;
    private String oefcat;


    public Oefcat(int oefcatid, String oefcat) {
        this.oefcatid = oefcatid;
        this.oefcat = oefcat;

    }

    public int getoefcatId() {
        return oefcatid;
    }

    public String getOefcat() {
        return oefcat;
    }


}
