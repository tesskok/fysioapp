package com.aless.fysiohellevoetsluis;


public class Favorite {
    private int id;


    public Favorite(int id) {
        this.id = id;

    }

    public int getId() {
        return id;
    }


}
