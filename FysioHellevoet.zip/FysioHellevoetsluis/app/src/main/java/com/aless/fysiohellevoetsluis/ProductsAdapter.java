package com.aless.fysiohellevoetsluis;

import android.app.Activity;
import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.LineNumberInputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

import static com.aless.fysiohellevoetsluis.SharedPrefManager.FAVORITES;
import static com.aless.fysiohellevoetsluis.SharedPrefManager.getUser;


public class ProductsAdapter extends RecyclerView.Adapter<ProductViewHolder> {


    private Context mCtx;
    private List<Product> productList;
    SharedPrefManager sharedPreference;


    public ProductsAdapter(Context mCtx, List<Product> productList) {
        this.mCtx = mCtx;
        this.productList = productList;
        sharedPreference = new SharedPrefManager();
    }


    @Override
    public ProductViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.product_list, null);
        return new ProductViewHolder(view);
    }


    @Override
    public void onBindViewHolder(final ProductViewHolder holder, final int position) {
        final Product product = productList.get(position);


        holder.mFavorite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (holder.mFavorite.getColorFilter() != null) {
                    holder.mFavorite.clearColorFilter();
                    removefav(product.getId());
                    sharedPreference.removeFavorite(mCtx, productList.get(position));

                } else {
                    holder.mFavorite.setColorFilter(ContextCompat.getColor(mCtx,
                            R.color.blauw));
                    favclick(product.getId());
                    sharedPreference.addFavorite(mCtx, productList.get(position));

            }

            }
        });

        //loading the image
        Glide.with(mCtx)
                .load(product.getImage())
                .into(holder.imageView);

        holder.textViewTitle.setText(product.getTitle());
        holder.textViewShortDesc.setText(product.getShortdesc());
        holder.relativeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View View) {
                Toast.makeText(mCtx, "U heeft geklikt op oefening" + product.getId(), Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(mCtx, FullscreenVideoActivity.class);
                intent.putExtra("video", product.getVideo());
                intent.putExtra("title", product.getTitle());
                intent.putExtra("uitleg", product.getShortdesc());
                mCtx.startActivity(intent);
            }
        });

        if(checkFavoriteItem(position)){
            holder.mFavorite.setColorFilter(ContextCompat.getColor(mCtx,
                    R.color.blauw));
        }else{
            holder.mFavorite.clearColorFilter();
        }
    }

    public boolean checkFavoriteItem(final int position){
        final Product product = productList.get(position);
        final int vid = product.getId();
        boolean check = false;
        List<Favorite> favorites = MainActivityVideo.favoList;
        if(favorites !=null){
            if (favorites.contains(vid)){
                    check = true;

            }

    }return check;

    }



    public void favclick(final int v_id){
        final String username = String.valueOf(User.getUserId());
        final String vid=String.valueOf(v_id);

        Toast.makeText(mCtx, " nu in favorieten: " +username +"------"+ v_id, Toast.LENGTH_LONG).show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL_addtofav,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String ServerResponse) {

                        // Hiding the progress dialog after all task complete.


                        // Showing response message coming from server.
                        Toast.makeText(mCtx, " nu in favorieten: " + ServerResponse, Toast.LENGTH_LONG).show();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {

                        // Hiding the progress dialog after all task complete.

                        // Showing error message if something goes wrong.
                        Toast.makeText(mCtx, " nu in favorieten: " + volleyError.toString(), Toast.LENGTH_LONG).show();

                    }
                }) {
            @Override
            protected Map<String, String> getParams() {

                // Creating Map String Params.
                Map<String, String> params = new HashMap<>();

                // Adding All values to Params.
                params.put("id", username);
                params.put("v_id", vid);

                return params;
            }

        };

        // Creating RequestQueue.
        RequestQueue requestQueue = Volley.newRequestQueue(mCtx);

        // Adding the StringRequest object into requestQueue.
        requestQueue.add(stringRequest);

    }


    public void removefav(final int v_id){
        final String username = String.valueOf(User.getUserId());
        final String vid=String.valueOf(v_id);
        Toast.makeText(mCtx, " nu uit favorieten: " +username +"------"+ v_id, Toast.LENGTH_LONG).show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL_DELETEFAV,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String ServerResponse) {

                        // Hiding the progress dialog after all task complete.


                        // Showing response message coming from server.
                        Toast.makeText(mCtx, " nu uit favorieten: " + ServerResponse, Toast.LENGTH_LONG).show();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {

                        // Hiding the progress dialog after all task complete.

                        // Showing error message if something goes wrong.
                        Toast.makeText(mCtx, " nu uit favorieten: " + volleyError.toString(), Toast.LENGTH_LONG).show();

                    }
                }) {
            @Override
            protected Map<String, String> getParams() {

                // Creating Map String Params.
                Map<String, String> params = new HashMap<>();

                // Adding All values to Params.
                params.put("id", username);
                params.put("v_id", vid);

                return params;
            }

        };

        // Creating RequestQueue.
        RequestQueue requestQueue = Volley.newRequestQueue(mCtx);

        // Adding the StringRequest object into requestQueue.
        requestQueue.add(stringRequest);
    }






    @Override
    public int getItemCount() {
        return productList.size();
    }
}
    class ProductViewHolder extends RecyclerView.ViewHolder {

        TextView textViewTitle, textViewShortDesc;
        ImageView imageView;
        RelativeLayout relativeLayout;
        ImageView mFavorite;

        ProductViewHolder(View itemView) {
            super(itemView);

            textViewTitle = itemView.findViewById(R.id.textViewTitle);
            textViewShortDesc = itemView.findViewById(R.id.textViewShortDesc);
            imageView = itemView.findViewById(R.id.imageView);
            relativeLayout =  itemView.findViewById(R.id.relativeLayout);
            mFavorite = itemView.findViewById(R.id.ivFavorite);




        }
    }



