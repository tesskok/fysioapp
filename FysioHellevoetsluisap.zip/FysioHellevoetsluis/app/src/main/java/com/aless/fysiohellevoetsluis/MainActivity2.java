package com.aless.fysiohellevoetsluis;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

/**
 * Created by Tess on 08-04-18.
 */

public class MainActivity2  extends AppCompatActivity {

    Button buttonoef, buttonFavorite;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        buttonFavorite=(Button)findViewById(R.id.buttonFavorite);
        buttonoef=(Button)findViewById(R.id.buttonoef);

        buttonFavorite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(MainActivity2.this,MainActivityFavorite.class);
                startActivity(i);
            }
        });

        buttonoef.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(MainActivity2.this,MainActivityoefcat.class);
                startActivity(i);
            }
        });
    }
}