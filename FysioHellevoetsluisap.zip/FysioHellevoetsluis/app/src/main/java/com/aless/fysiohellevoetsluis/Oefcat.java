package com.aless.fysiohellevoetsluis;

/**
 * Created by Belal on 10/18/2017.
 */

public class Oefcat {
    private int oefcatid;
    private String oefcat;


    public Oefcat(int oefcatid, String oefcat) {
        this.oefcatid = oefcatid;
        this.oefcat = oefcat;

    }

    public int getoefcatId() {
        return oefcatid;
    }

    public String getOefcat() {
        return oefcat;
    }


}
