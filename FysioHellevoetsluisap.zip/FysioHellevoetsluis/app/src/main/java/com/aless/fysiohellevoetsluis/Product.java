package com.aless.fysiohellevoetsluis;

/**
 * Created by Belal on 10/18/2017.
 */

public class Product {
    private int id;
    private String title;
    private String shortdesc;
    private String image;

    public Product(int id, String title, String shortdesc, String image) {
        this.id = id;
        this.title = title;
        this.shortdesc = shortdesc;
        this.image = "http://10.0.2.2:8080/test/uploads/"+image;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getShortdesc() {
        return shortdesc;
    }

    public String getImage() {
        return image;
    }

}
