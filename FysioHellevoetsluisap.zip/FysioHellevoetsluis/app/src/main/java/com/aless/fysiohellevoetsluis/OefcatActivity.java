package com.aless.fysiohellevoetsluis;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.TextView;

/**
 * Created by Tess on 25-03-18.
 */

public class OefcatActivity extends AppCompatActivity{
   private static final String TAG ="OefcatActivity";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_oefcat);
        Log.d(TAG, "onCreate: started");

        getIncomingIntent();
    }

    private void getIncomingIntent(){
        Log.d(TAG, "getIncomingIntent:checking for");
        if (getIntent().hasExtra("oefcat")){
            Log.d(TAG, "getIncomingIntent; found");


            String oefcat = getIntent().getStringExtra("oefcat");


            setImage(oefcat);
        }
    }

    private void setImage(String oefcat) {
        Log.d(TAG, "setImage:fsdfsd");


        TextView Oefcat = findViewById(R.id.image_title);
        Oefcat.setText(oefcat);


    }

}
